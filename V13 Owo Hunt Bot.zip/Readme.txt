
English version;

The package supports Turkish, you can buy the English version for 20 TL. 
To get support during the installation phase or if you have any other problems


Discord Name: mrtrengh

Server: https://discord.gg/eBPmwqfsTT

---------------------------------------------------------------------------------------------------------------

T�rk�e versiyon;

Paket t�rk�e desteklidir, Kurulum a�amas�nda destek almak i�in veya ba�ka bir sorun ya�arsan�z

Discord ismim: mrtrengh

Sunucum: https://discord.gg/eBPmwqfsTT