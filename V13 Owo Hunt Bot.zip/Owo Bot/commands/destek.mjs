export default {
    info: "Destek sunucusu bağlantısını gönderir.",
    callback: (message, ...args) => {
        message.reply("Sorun mu yaşıyorsunuz? Destek sunucumuza katılın: https://discord.gg/UqACGe6pub")
    }
}